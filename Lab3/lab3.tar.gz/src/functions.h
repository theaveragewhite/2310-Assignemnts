/*
 * Name: Colton Owenby
 * Date Submitted: 9/14/2023
 * Lab Section: 001
 * Assignment Name: Lab 3
 * Email: coltono@clemson.edu
 */

#ifndef FUNCTION_H
#define FUNCTION_H

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

//Function Prototypes
void numSentences(FILE* in, FILE* out);
void numWords(FILE* in, FILE* out);

#endif
